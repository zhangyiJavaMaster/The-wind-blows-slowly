package com.elon.dds.contreller;

import com.elon.dds.datasource.DBIdentifier;
import com.elon.dds.mapper.UserMapper;
import com.elon.dds.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class zytestCon {

    @ResponseBody
    @RequestMapping("hello")
    public String hello(){

        return "123124";
    }

    @Autowired
    private UserMapper userMapper;
    /**
     * 查询项目中所有用户信息
     *
     * @param projectCode 项目编码
     * @return 用户列表
     */
    @RequestMapping(value="/v1/users", method= RequestMethod.GET)
    public List<User> queryUser(@RequestParam(value="projectCode", required=true) String projectCode)
    {
        DBIdentifier.setProjectCode(projectCode);
        return userMapper.getUsers();
        // http://localhost:8082/v1/users?projectCode=project_003
    }
}
