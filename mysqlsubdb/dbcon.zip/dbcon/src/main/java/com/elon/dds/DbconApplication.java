package com.elon.dds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
* 支持数据库动态增删，数量不限
* https://www.jb51.net/article/135688.htm
* */
@SpringBootApplication
public class DbconApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbconApplication.class, args);
    }

}
